#include <bits/stdc++.h>

class Ticket{
public:
    static int ID;
    static map<int, Ticket> ticketList;
    int ticketID;
    int passengerID;
    int travelID;
    string source;
    string destination;
    double cost;
    tm bookingTime;
    tm travelDate;
    tm validUpto;
    string status;
    Ticket(int passID, string src, string dest, tm bookingtime, tm travaldate);
    void printTicket();
    void deleteTicket();
    void updateTravel();
    void updateStatus(string state);
    void updateTravelID(int x);
    void updateTime(tm date);
    void updateSource(string src);
    void updateDestination(string dest);
};

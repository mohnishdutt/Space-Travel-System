#include <bits/stdc++.h>
using namespace std;

class Planet{
public:
    static map<string, Planet> planetList;
    double xPosition; 
    double yPosition; 
    double zPosition; 
    string planetName;
    Planet(double x, double y, double z, string name);
    void updateX(int x);
    void updateY(int y);
    void updateZ(int z);
    void updateName(string name);
    double getPositionX();
    double getPositionY();
    double getPositionZ();
    string getPlanetName();
    void getPosition();
};

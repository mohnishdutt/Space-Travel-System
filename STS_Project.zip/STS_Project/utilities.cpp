#include <bits/stdc++.h>
#include "headerPlanet.h"
#include "headerAllTravellers.h"
using namespace std;

bool isSameDate(const tm &date1, const tm &date2){
    return (date1.tm_year == date2.tm_year) && (date1.tm_mon == date2.tm_mon) && (date1.tm_mday == date2.tm_mday);
}

double getDistance(string fromPlanet, string toPlanet){
    auto planet1 = Planet :: planetList.find(fromPlanet);
    auto planet2 = Planet :: planetList.find(toPlanet);
    Planet A = planet1 -> second;
    Planet B = planet2 -> second;
    double distance = sqrt((A.getPositionX() - B.getPositionX()) * (A.getPositionX() - B.getPositionX()) + (A.getPositionY() - B.getPositionY()) * (A.getPositionY() - B.getPositionY()) + (A.getPositionZ() - B.getPositionZ()) * (A.getPositionZ() - B.getPositionZ()));
    return distance;
}

int getAstronaut(tm date){
    for(auto it = Astronaut :: astronautList.begin(); it != Astronaut :: astronautList.end(); ){
        int k = 1;
        for(int i = 0; i < it -> second.workingDates.size(); i++){
            if(isSameDate(it -> second.workingDates[i], date)){
                k = 0;
            }
        }
        if(k != 0){
            it -> second.addWorkingDay(date);
            return it -> second.ID;
        }
        else {
            it++;
        }
    }
    return 0;
}

int getCommander(tm date){
    for(auto it = Commander :: commanderList.begin(); it != Commander :: commanderList.end(); ){
        int k = 1;
        for(int i = 0; i < it -> second.workingDates.size(); i++){
            if(isSameDate(it -> second.workingDates[i], date)){
                k = 0;
            }
        }
        if(k != 0){
            it -> second.addWorkingDay(date);
            return it -> second.ID;
        }
        else {
            it++;
        }
    }
    return 0;
}

void deleteCommanderAstronautWorkingDate(int astID, int comID, tm date){
    Astronaut :: astronautList.find(astID) -> second.deleteWorkingDay(date);
    Commander :: commanderList.find(comID) -> second.deleteWorkingDay(date);
}
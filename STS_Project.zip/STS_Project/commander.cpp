#include <bits/stdc++.h>
#include "headerAllTravellers.h"
#include "headerutilities.h"
#include "headerSpaceTravel.h"
using namespace std;

Commander :: Commander(string Name, int id, int licID, int exp){
    name = Name;
    ID = id;
    licenseID = licID;
    experience = exp;
    totalID.insert(id);
    commanderList.insert(make_pair(ID, *this));
}
void Commander :: showWorkingDates(){
    if(workingDates.size() == 0){
        cout << "\nNo Working Days\n" << '\n';
        return;
    }
    for(auto it = workingDates.begin(); it != workingDates.end(); it++){
        cout << "Working Day : " << it -> tm_mday << "/" << it -> tm_mon + 1 << "/" << it -> tm_year + 1900 << '\n';
    }
}
void Commander :: listTravels(){
    if(SpaceTravel :: spaceTravelList.size() == 0){
        cout << "\nThere are no Upcoming Journey\n" << '\n';
        return;
    }
    for(auto it : SpaceTravel :: spaceTravelList){
        SpaceTravel T = it.second;
        cout << T.source << " to " << T.destination << " on " << T.travelDate.tm_mday << "/" << T.travelDate.tm_mon + 1 << "/" << T.travelDate.tm_year + 1900 << '\n';
    }
}
void Commander :: listAuthorities(){
    for(auto it = Astronaut :: astronautList.begin(); it != Astronaut :: astronautList.end(); ){
        cout << "Name: " << it -> second.name << "  ID: " << it -> second.ID << " ";
        it -> second.showWorkingDates();
        it++;
    }
    for(auto it = commanderList.begin(); it != commanderList.end(); ){
        cout << "Name: " << it -> second.name << "  ID: " << it -> second.ID << " ";
        it -> second.showWorkingDates();
        it++;
    }
}
void Commander :: updateLicenseID(int licID){
    licenseID = licID;
    commanderList.erase(ID);
    commanderList.insert(make_pair(ID, *this));
}
void Commander :: addWorkingDay(tm date){
    workingDates.push_back(date);
    commanderList.erase(ID);
    commanderList.insert(make_pair(ID, *this));
}
void Commander :: deleteWorkingDay(tm date){
    for(auto it = workingDates.begin(); it != workingDates.end(); ){
        if(isSameDate(*it, date)){
            it = workingDates.erase(it);
        }
        else {
            it++;
        }
    }
}

#include <bits/stdc++.h>
#include "headerutilities.h"
#include "headerAllTravellers.h"
using namespace std;

string Traveller :: getName(){
    return name;
}
int Traveller :: getID(){
    return ID;
}
int Traveller :: verifyID(int id){
    if(totalID.find(id) != totalID.end()){
        return 1;
    }
    else {
        return 0;
    }
}
void Traveller :: updateName(string Name){
    name = Name;
}
void Traveller :: updateID(int id){
    if(verifyID(id) == 0){
        totalID.erase(ID);
        ID = id;
        totalID.insert(id);
    }
    else {
        cout << "\nID is Already Existing\n" << '\n';
    }
}
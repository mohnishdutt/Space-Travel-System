#include <bits/stdc++.h>
using namespace std;

class Traveller{
public:
    string name;
    int ID;
    string getName();
    int getID();
    int verifyID(int id);
    void updateName(string Name);
    void updateID(int id);
};

class Passenger : public Traveller{
public:
    static map<int, Passenger> passengerList;
    vector<int> listOfTickets;
    Passenger(string Name, int id);
    void listTickets();
    void getTicket(int x);
};

class Astronaut : public Traveller{
public:
    vector<tm> workingDates;
    static map<int, Astronaut>astronautList;
    int licenseID;
    int experience;
    Astronaut(string Name, int id, int licID, int exp);
    void showWorkingDates();
    void updateLicenseID(int licID);
    void addWorkingDay(tm date);
    void deleteWorkingDay(tm date);
};

class Commander : public Traveller{
public:
    vector<tm> workingDates;
    static map<int, Commander> commanderList;
    int licenseID;
    int experience;
    Commander(string Name, int id, int licID, int exp);
    void showWorkingDates();
    void listTravels();
    void listAuthorities();
    void updateLicenseID(int licID);
    void addWorkingDay(tm date);
    void deleteWorkingDay(tm date);
};
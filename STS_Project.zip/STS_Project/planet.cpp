#include <bits/stdc++.h>
#include "headerPlanet.h"
using namespace std;

Planet :: Planet(double x, double y, double z, string name){
    xPosition = x;
    yPosition = y;
    zPosition = z;
    planetName = name;
    planetList.insert(pair<string, Planet>(planetName, *this));
}
void Planet :: updateX(int x){
    xPosition = x;
}
void Planet :: updateY(int y){
    yPosition = y;
}
void Planet :: updateZ(int z){
    zPosition = z;
}
void Planet :: updateName(string name){
    planetName = name;
}
double Planet :: getPositionX(){
    return xPosition;
}
double Planet :: getPositionY(){
    return yPosition;
}
double Planet :: getPositionZ(){
    return zPosition;
}
string Planet :: getPlanetName(){
    return planetName;
}
void Planet :: getPosition(){
    cout << "X: " << getPositionX() << ", Y: " << getPositionY() << ", Z: " << getPositionZ() << '\n';
}

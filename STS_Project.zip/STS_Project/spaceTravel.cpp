#include <bits/stdc++.h>
#include "headerutilities.h"
#include "headerSpaceTravel.h"
using namespace std;

SpaceTravel :: SpaceTravel(string src, string dest, tm date, int astro, int comm){
    spaceTravelID = ++ID;
    source = src;
    destination = dest;
    travelDate = date;
    astronaut = astro;
    commander = comm;
}
void SpaceTravel :: addPassenger(int id){
    passenger.push_back(id);
    spaceTravelList.erase(spaceTravelID);
    spaceTravelList.insert(make_pair(spaceTravelID, *this));
}
void SpaceTravel :: deletePassenger(int id){
    if(passenger.size() > 2){
        auto it = find(passenger.begin(), passenger.end(), id);
        passenger.erase(it);
        spaceTravelList.erase(spaceTravelID);
        spaceTravelList.insert(make_pair(spaceTravelID, *this));
    }
    else{
        deleteCommanderAstronautWorkingDate(commander, astronaut, travelDate);
        spaceTravelList.erase(spaceTravelID);
    }
}
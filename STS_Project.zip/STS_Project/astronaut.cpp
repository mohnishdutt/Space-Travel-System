#include <bits/stdc++.h>
#include "headerAllTravellers.h"
#include "headerutilities.h"
using namespace std;

Astronaut :: Astronaut(string Name, int id, int licID, int exp){
    name = Name;
    ID = id;
    licenseID = licID;
    experience = exp;
    totalID.insert(id);
    astronautList.insert(make_pair(ID, *this));
}
void Astronaut :: showWorkingDates(){
    if(workingDates.size() == 0){
        cout << "\nNo Working Days\n" << '\n';
        return;
    }
    for(auto it = workingDates.begin(); it != workingDates.end(); it++){
        cout << "Working Day  : " << it -> tm_mday << "/" << it -> tm_mon + 1 << "/" << it -> tm_year + 1900 << '\n';
    }
}
void Astronaut :: updateLicenseID(int licID){
    licenseID = licID;
    astronautList.erase(ID);
    astronautList.insert(make_pair(ID, *this));
}
void Astronaut :: addWorkingDay(tm date){
    workingDates.push_back(date);
    astronautList.erase(ID);
    astronautList.insert(make_pair(ID, *this));
}
void Astronaut :: deleteWorkingDay(tm date){
    for(auto it = workingDates.begin(); it != workingDates.end(); ){
        if(isSameDate(*it, date)){
            it = workingDates.erase(it);
        }
        else {
            it++;
        }
    }
}
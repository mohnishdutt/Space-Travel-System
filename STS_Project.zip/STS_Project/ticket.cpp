#include <bits/stdc++.h>
#include "headerutilities.h"
#include "headerSpaceTravel.h"
#include "headerTicket.h"
using namespace std;

Ticket :: Ticket(int passID, string src, string dest, tm bookingtime, tm travaldate){
    ticketID = ++ID;
    passengerID = passID;
    source = src;
    destination = dest;
    bookingTime = bookingtime;
    travelDate = travaldate;
    status = "Pending";
    cost = 1000 * getDistance(source, destination)/(difftime(mktime(&travelDate), mktime(&bookingTime)) / (60 * 60 * 24) + 1);
    validUpto.tm_mday = bookingTime.tm_mday;
    validUpto.tm_mon = bookingTime.tm_mon;
    validUpto.tm_year = bookingTime.tm_year + 100;
    ticketList.insert(make_pair(ticketID, *this));
}
void Ticket :: printTicket(){
    cout << "\n======================================" << endl;
    cout << "               InterPlanet            " << endl;
    cout << "           Ticket Confirmation        " << endl;
    cout << "======================================" << endl;
    cout << "  Ticket ID     : " << ticketID << endl;
    cout << "  Passenger ID  : " << passengerID << endl;
    cout << "  Source        : " << source << endl;
    cout << "  Destination   : " << destination << endl;
    cout << "  Booking Time  : " << bookingTime.tm_mday << "/" << bookingTime.tm_mon + 1 << "/" << bookingTime.tm_year + 1900 << endl;
    cout << "  Travel Date   : " << travelDate.tm_mday << "/" << travelDate.tm_mon + 1 << "/" << travelDate.tm_year + 1900 << endl;
    cout << "  Valid Upto    : " << validUpto.tm_mday << "/" << validUpto.tm_mon + 1 << "/" << validUpto.tm_year + 1900 << endl;
    cout << "  Cost          : $" << fixed << setprecision(2) << cost << endl;
    cout << "  Travel Status : " << status << endl;
    cout << "======================================" << endl;
}
void Ticket :: deleteTicket(){
    ticketList.erase(ticketID);
}
void Ticket :: updateTravel(){
    for(auto it1 = ticketList.begin(); it1 != ticketList.end(); it1++){
        for(auto it2 = next(it1); it2 != ticketList.end(); it2++){
            string check = "Confirmed";
            if((isSameDate(it1 -> second.travelDate, it2 -> second.travelDate)) && (it1 -> second.source == it2 -> second.source) && (it1 -> second.destination == it2 -> second.destination)){
                if((it1 -> second.status != check) && (it2 -> second.status != check)){
                    if(getAstronaut(it1 -> second.travelDate) && getCommander(it1 -> second.travelDate)){
                        SpaceTravel s(it1 -> second.source, it1 -> second.destination, it1 -> second.travelDate, getAstronaut(it1 -> second.travelDate), getCommander(it1 -> second.travelDate));
                        s.addPassenger(it1 -> second.passengerID);
                        s.addPassenger(it2 -> second.passengerID);
                        it1 -> second.updateStatus(check);
                        it2 -> second.updateStatus(check);
                        it1 -> second.updateTravelID(s.spaceTravelID);
                        it2 -> second.updateTravelID(s.spaceTravelID);
                    }
                }
                else if((it1 -> second.status == check) && (it2 -> second.status != check)){
                    SpaceTravel s = SpaceTravel :: spaceTravelList.find(it1 -> second.travelID) -> second;
                    if(s.passenger.size() < 10){
                        s.addPassenger(it2 -> second.passengerID);
                        it2 -> second.updateStatus(check);
                        it2 -> second.updateTravelID(s.spaceTravelID);
                    }
                }
                else if((it1 -> second.status != check) && (it2 -> second.status == check)){
                    SpaceTravel s = SpaceTravel :: spaceTravelList.find(it2 -> second.travelID) -> second;
                    if(s.passenger.size() < 10){
                        s.addPassenger(it1 -> second.passengerID);
                        it1 -> second.updateStatus(check);
                        it1 -> second.updateTravelID(s.spaceTravelID);
                    }
                }
            }
        }
    }
}
void Ticket :: updateStatus(string state){
    status = state;
    ticketList.erase(ticketID);
    ticketList.insert(make_pair(ticketID, *this));
}
void Ticket :: updateTravelID(int x){
    travelID = x;
    ticketList.erase(ticketID);
    ticketList.insert(make_pair(ticketID, *this));
}
void Ticket :: updateTime(tm date){
    travelDate = date;
    cost = 1000 * getDistance(source, destination) / (difftime(mktime(&travelDate), mktime(&bookingTime)) / (60 * 60 * 24) + 1);
    if(status == "Confirmed"){
        SpaceTravel :: spaceTravelList.find(travelID) -> second.deletePassenger(passengerID);
    }
    status = "Pending";
    ticketList.erase(ticketID);
    ticketList.insert(make_pair(ticketID, *this));
}
void Ticket :: updateSource(string src){
    source = src;
    cost = 1000 * getDistance(source, destination) / (difftime(mktime(&travelDate), mktime(&bookingTime)) / (60 * 60 * 24) + 1);
    if(status == "Confirmed"){
        SpaceTravel :: spaceTravelList.find(travelID) -> second.deletePassenger(passengerID);
    }
    status = "Pending";
    ticketList.erase(ticketID);
    ticketList.insert(make_pair(ticketID, *this));
}
void Ticket :: updateDestination(string dest){
    destination = dest;
    cost = 1000 * getDistance(source, destination) / (difftime(mktime(&travelDate), mktime(&bookingTime)) / (60 * 60 * 24) + 1);
    if(status == "Confirmed"){
        SpaceTravel :: spaceTravelList.find(travelID) -> second.deletePassenger(passengerID);
    }
    status = "Pending";
    ticketList.erase(ticketID);
    ticketList.insert(make_pair(ticketID, *this));
}
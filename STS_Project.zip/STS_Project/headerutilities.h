#include <bits/stdc++.h>
using namespace std;

extern set<int> totalID;
extern set<int> licenseID;

double getDistance(string fromPlanet, string toPlanet);

void deleteCommanderAstronautWorkingDate(int a, int b, tm date);

bool isSameDate(const tm &date1, const tm &date2);

int getAstronaut(tm date);

int getCommander(tm date);

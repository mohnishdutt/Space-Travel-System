#include <bits/stdc++.h>

class SpaceTravel{
public:
    static int ID;
    static map<int, SpaceTravel> spaceTravelList;
    int spaceTravelID;
    int astronaut;
    int commander;
    vector<int> passenger;
    string source;
    string destination;
    tm travelDate;
    SpaceTravel(string src, string dest, tm date, int astro, int comm);
    void addPassenger(int id);
    void deletePassenger(int id);
};

#include <bits/stdc++.h>
#include "headerutilities.h"
#include "headerAllTravellers.h"
#include "headerTicket.h"
using namespace std;

Passenger :: Passenger(string Name, int id){
    name = Name;
    ID = id;
    totalID.insert(id);
    passengerList.insert(make_pair(ID, *this));
}
void Passenger :: listTickets(){
    if(listOfTickets.size() == 0){
        cout << "\nYou do not have Upcoming Journey\n" << '\n';
    }
    for(auto it : listOfTickets){
        Ticket T = Ticket :: ticketList.find(it) -> second;
        cout << it << " " << T.source << " to  " << T.destination << " on " << T.travelDate.tm_mday << "/" << T.travelDate.tm_mon + 1 << "/" << T.travelDate.tm_year + 1900 << '\n';
    }
}
void Passenger :: getTicket(int x){
    Ticket :: ticketList.find(x) -> second.printTicket();
}
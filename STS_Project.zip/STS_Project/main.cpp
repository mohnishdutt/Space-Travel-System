#include <bits/stdc++.h>
#include "headerPlanet.h"
#include "headerutilities.h"
#include "headerTicket.h"
#include "headerSpaceTravel.h"
#include "headerAllTravellers.h"
using namespace std;

map<string, Planet> Planet :: planetList;
map<int, SpaceTravel> SpaceTravel :: spaceTravelList;
map<int, Ticket> Ticket :: ticketList;
map<int, Passenger> Passenger :: passengerList;
map<int, Astronaut> Astronaut :: astronautList;
map<int, Commander> Commander :: commanderList;

int Ticket :: ID = 0;
int SpaceTravel :: ID = 0;
set<int> licenseID;
set<int> totalID;

int main(){
    Planet Earth(0.0, 0.0, 0.0, "Earth");
    Planet Moon(1.5, 1.23, -0.43, "Moon");
    Planet Mercury(-4.78, -6.21, 1.03, "Mercury");
    Planet Venus(-2.23, -3.76, 1.96, "Venus");
    Planet Mars(3.58, 2.75, -3.03, "Mars");
    Passenger p1("Neel", 1);
    Passenger p2("Nitin", 2);
    Passenger p3("Mukesh", 3);
    Passenger p4("Poplu", 4);
    Passenger p5("Lola", 5);
    Passenger p6("Chucha", 6);
    Passenger p7("Muttu", 7);
    Passenger p8("Cheena", 8);
    Passenger p9("Champa", 9);
    Passenger p10("Bhutta", 10);
    Astronaut a1("Ast.Sonti", 69, 9989, 9);
    Astronaut a2("Ast.Ponti", 70, 9981, 8);
    Astronaut a3("Ast.Rolaa", 71, 9908, 5);
    Commander c1("Comd.Hilau", 13, 1289, 13);
    Commander c2("Comd.Goli", 17, 1280, 15);
    string response;
    string exit = "exit()";
    string help = "help()";
    string plogin = "passenger.login()";
    string alogin = "astronaut.login()";
    string clogin = "commander.login()";
    string logout = "logout()";
    cout << "Welcome to Space Travel System!!! \n\nFor User manual please type help().\n\n";
    
    while(response != exit){
        cin >> response;
        if(response == help){
            cout << "\nYou can login as a Passenger or Astronaut or Commander by the following commands.\n";
            cout << "1. passenger.login()\n2. astronaut.login()\n3. commander.login()\n";
            cout << "You should enter your name and ID to login to your Account.\n";
            cout << "Please note that the program terminates only on Ctrl + C or exit() when logged out.\n";
            cout << "To logout please enter logout().\nTo exit the program please enter exit().\n\n";
        }
        else if(response == plogin){
            string name;
            int id;
            cout << "\nPlease Enter Your Name: ";
            cin >> name;
            cout << "\nPlease Enter Your ID: ";
            cin >> id;
            if(Passenger :: passengerList.find(id) != Passenger :: passengerList.end() && Passenger :: passengerList.find(id) -> second.getName() == name){
                Passenger P = Passenger :: passengerList.find(id) -> second;
                cout << "\nWelcome Passenger " << name << "! \nYou can do the following task\n";
                cout << "A) Book a Ticket \nB) See all your booked tickets \nC) Print a ticket \nD) Update a ticket \n";
                cout << "E) Cancel a ticket \n\nYou can use logout() to logout any time.\nPlease Select Your Choice: "; 
                cin >> response;
                while(response != logout){
                    int ret = 0;
                    if(response == "A"){
                        cout << "\nCurrently we are operating between these Plantes - ";
                        for(auto pair : Planet :: planetList){
                            cout << pair.first << " ";
                        }
                        cout << ".\n\n";
                        string source, destination, day;
                        tm date = {};
                        cout << "Please Select Your Source: ";
                        cin >> source;
                        cout << "Please Select Your Destination: ";
                        cin >> destination;
                        cout << "Please Select Your Travell Date in DD-MM-YYYY format: ";
                        cin >> day;
                        auto now = chrono :: system_clock :: now();
                        time_t timeNow = chrono :: system_clock :: to_time_t(now);
                        tm *ptm = localtime(&timeNow);
                        ptm -> tm_hour = 0;
                        ptm -> tm_min = 0;
                        ptm -> tm_sec = 0;
                        istringstream ss(day);
                        ss >> get_time(&date, "%d-%m-%Y");
                        if(source == destination || Planet :: planetList.find(source) == Planet :: planetList.end() || Planet :: planetList.find(destination) == Planet :: planetList.end() || ss.fail() || (difftime(mktime(&date), mktime(ptm)) < 0)){
                            cout << "\nInvalid Credentials\n\n";
                        }
                        else {
                            Ticket T(id, source, destination, *ptm, date);
                            cout << "\nThe cost of the ticket is " << fixed << setprecision(2) << T.cost << "\nDo you want to continue to Book (Yes/No) ? ";
                            string confirm;
                            cin >> confirm;
                            if(confirm == "Yes"){
                                P.listOfTickets.push_back(T.ticketID);
                                T.updateTravel();
                                cout << "\nYour ticket is booked and your Ticket ID is : " << T.ID <<". You can see the ticket in your tickets now. Do you want to continue to book return ticket (Yes/No) ? ";
                                cin >> confirm;
                                if(confirm == " Yes"){
                                    ret = 1;
                                }
                            }
                            else {
                                T.deleteTicket();
                            }
                        }
                    }
                    else if(response == "B"){
                        P.listTickets();
                    }
                    else if(response == "C"){
                        int id;
                        cout << "\nEnter the ticket ID: ";
                        cin >> id;
                        P.getTicket(id);
                    }
                    else if(response == "D"){
                        int id;
                        cout << "Enter the ticket ID: ";
                        cin >> id;
                        if(Ticket :: ticketList.find(id) != Ticket :: ticketList.end()){
                            cout << "\nA) Change Travel Date \nB) Change Destination \nC) Change Source \n\n";
                            string choice;
                            cout << "Please Select Your Choice: ";
                            cin >> choice;
                            Ticket T = Ticket :: ticketList.find(id) -> second;
                            if(choice == "A"){
                                string day;
                                tm date = {};
                                auto now = chrono :: system_clock :: now();
                                time_t timeNow = chrono :: system_clock :: to_time_t(now);
                                tm *ptm = localtime(&timeNow);
                                ptm -> tm_hour = 0;
                                ptm -> tm_min = 0;
                                ptm -> tm_sec = 0;
                                cout << "Please Select Your Travel Date in DD-MM-YYY formate: ";
                                cin >> day;
                                istringstream ss(day);
                                ss >> get_time(&date, "%d-%m-%Y");
                                if(ss.fail() || (difftime(mktime(&date), mktime(ptm)) < 0)){
                                    cout << "\nInvalid Credentials\n\n";
                                }
                                else {
                                    double price = T.cost;
                                    T.updateTime(date);
                                    T.updateTravel();
                                    double price2 = T.cost;
                                    cout << "\nSucessfully updated Travel Date. Your Balance is changed by $" << fixed << setprecision(2) << price - price2 << "\n\n";
                                }
                            }
                            else if(choice == "B"){
                                string destination;
                                cout << "Please Select Your Destination: ";
                                cin >> destination;
                                if(T.source == destination || Planet :: planetList.find(destination) == Planet :: planetList.end()){
                                    cout << "\nInvalid Credentials\n\n";
                                }
                                else {
                                    double price = T.cost;
                                    T.updateDestination(destination);
                                    T.updateTravel();
                                    double price2 = T.cost;
                                    cout << "\nSucessfully updated Destination. Your Balance is changed by $" << fixed << setprecision(2) << price - price2 << "\n\n";
                                }
                            }
                            else if(choice == "C"){
                                string source;
                                cout << "Please Select Your Source: ";
                                cin >> source;
                                if(source == T.destination || Planet :: planetList.find(source) == Planet :: planetList.end()){
                                    cout << "\nInvalid Credentials\n\n";
                                }
                                else {
                                    double price = T.cost;
                                    T.updateSource(source);
                                    T.updateTravel();
                                    double price2 = T.cost;
                                    cout << "\nSucessfully updated Source. Your Balance is changed by $" << fixed << setprecision(2) << price - price2 << "\n\n";
                                }
                            }
                        }
                    }
                    else if(response == "E"){
                        int id;
                        cout << "\nEnter the ticket ID: ";
                        cin >> id;
                        Ticket :: ticketList.find(id) -> second.deleteTicket();
                        cout << "\nYour Ticket is Successfully Cancelled!!!\n\n";
                    }
                    if(ret == 0){
                        cout << "Please Select Your Choice: ";
                        cin >> response;
                    } 
                }
            }
            else {
                cout << "\nInvalid Credentials \nYour are taken to main Page \nPlease login again\n\n";
                response = logout;
            }
        }
        else if(response == alogin){
            string name;
            int id;
            cout << "\nPlease Enter Your Name: ";
            cin >> name;
            cout << "\nPlease Enter Your ID: ";
            cin >> id;
            if(Astronaut :: astronautList.find(id) != Astronaut :: astronautList.end() && Astronaut :: astronautList.find(id) -> second.getName() == name){
                Astronaut A = Astronaut :: astronautList.find(id) -> second;
                cout << "\nWelcome Astronaut " << name << "! \n\nYou can do the following tasks \nA) See your Working days \n";
                cout << "B) Update your License ID \n\nYou can use logout() here any time \n\nPlease  Select Your Choice: ";
                cin >> response;
                while(response != logout){
                    if(response == "A"){
                        A.showWorkingDates();
                    }
                    else if(response == "B"){
                        int id;
                        cout << "\nEnter License ID: ";
                        cin >> id;
                        if(licenseID.find(id) == licenseID.end()){
                            licenseID.erase(A.licenseID);
                            A.updateLicenseID(id);
                            licenseID.insert(A.licenseID);
                            cout << "\nUpdated Successfully!\n\n";
                        }
                        else {
                            cout << "\nInvalid License ID\n\n";
                        }
                    }
                    cout << "Please Select Your Choice: ";
                    cin >> response;
                }
            }
            else {
                cout << "\nInvalid Credentials \nYou are taken to main Page \nPlease login again\n\n ";
                response = logout;
            }
        }
        else if(response == clogin){
            string name;
            int id;
            cout <<"\nPlease Enter Your Name: ";
            cin >> name;
            cout << "Please Enter Your ID: ";
            cin >> id;
            if(Commander :: commanderList.find(id) != Commander :: commanderList.end() && Commander :: commanderList.find(id) -> second.getName() == name){
                Commander C = Commander :: commanderList.find(id) -> second;
                cout << "\nWelcome Commander " << name << "! \n\nYou can do following tasks \nA) See your Working days\n B) See all the Travels \n";
                cout << "C) See all the working days of authorities\nD) Update your License ID\n\nYou can use logout() here any time\n\nPlease Select Your Choice: ";
                cin >> response;
                while(response != logout){
                    if(response == "A"){
                        C.showWorkingDates();
                    }
                    else if(response == "B"){
                        C.listTravels();
                    }
                    else if(response == "C"){
                        C.listAuthorities();
                    }
                    else if(response == "D"){
                        int id;
                        cout << "Enter your License ID: ";
                        cin >> id;
                        if(licenseID.find(id) == licenseID.end()){
                            licenseID.erase(C.licenseID);
                            C.updateLicenseID(id);
                            licenseID.insert(C.licenseID);
                            cout <<"\nUpdated Sucessfully\n\n";
                        }
                        else {
                            cout << "\nInvalid License ID\n\n";
                        }
                    }
                    cout << "Please Select Your Choice: ";
                    cin >> response;
                }
            }
            else {
                cout << "\nInvalid Credentials \nYou are taken to main Page \nPlease login again\n\n";
                response = logout;
            }
        }
    }
    return 0;
}